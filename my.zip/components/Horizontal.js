/* @flow */

import React, { Component } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Dimensions
} from 'react-native';


export default class Horizontal extends Component {
  render() {
    return (
      <ScrollView horizontal={true} pagingEnabled={true}>
        <View style={styles.outer}>
          <Text style={styles.text}> Welcome to my App </Text>
        </View>
        <View style={[styles.outer, styles.orange]}>
          <Text style={styles.text}> Best Quality Videos </Text>
        </View>
        <View style={[styles.outer, styles.green]}>
          <Text style={styles.text}> Available on android and ios </Text>
        </View>
      </ScrollView>
    );
  }
}

const styles = StyleSheet.create({
  outer: {
    flex: 1,
    backgroundColor: '#0C98E2',
    alignItems: 'center',
    justifyContent: 'center',
    width: Dimensions.get('window').width,
    height: Dimensions.get('window').height
  },
  text: {
    color: '#fff',
    fontSize: 23,
    fontWeight: 'bold'
  },
  orange: {
    backgroundColor: '#E8290B'
  },
  green: {
    backgroundColor: 'green'
  }
});
